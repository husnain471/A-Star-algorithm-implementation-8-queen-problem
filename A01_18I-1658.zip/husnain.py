import sys
import numpy as np
from queue import Queue

#******************************************Creating the Maze Board************************************
def createMazeTable(rows,col):
        matrix = np.zeros((rows, col))
        matrix = matrix.astype('int')

        matrix[10][0] = 1  

        matrix[1][1] = 1
        matrix[2][1] = 1
        matrix[4][1] = 1
        matrix[6][1] = 1
        matrix[8][1] = 1
        matrix[10][1] = 1

        matrix[1][2] = 1
        matrix[4][2] = 1
        matrix[6][2] = 1
        matrix[7][2] = 1
        matrix[8][2] = 1
        matrix[10][2] = 1

        matrix[1][3] = 1
        matrix[2][3] = 1
        matrix[3][3] = 1
        matrix[4][3] = 1
        matrix[8][3] = 1
        matrix[10][3] = 1

        matrix[4][4] = 1
        matrix[5][4] = 1
        matrix[6][4] = 1
        matrix[7][4] = 1
        matrix[8][4] = 1
        matrix[10][4] = 1

        matrix[1][5] = 1
        matrix[2][5] = 1
        matrix[3][5] = 1
        matrix[8][5] = 1
        matrix[10][5] = 1


        matrix[1][7] = 1
        matrix[3][7] = 1
        matrix[8][7] = 1
        matrix[7][7] = 1
        
        matrix[1][6] = 1
        matrix[3][6] = 1
        matrix[5][6] = 1
        matrix[6][6] = 1
        matrix[7][6] = 1
        matrix[8][6] = 1
        matrix[9][6] = 1
        matrix[10][6] = 1


        matrix[1][8] = 1
        matrix[3][8] = 1
        matrix[4][8] = 1
        matrix[5][8] = 1
        matrix[6][8] = 1        
        matrix[7][8] = 1
        matrix[8][8] = 1
        matrix[10][8] = 1

        matrix[1][9] = 1
        matrix[10][9] = 1
        
        matrix[1][10] = 1
        matrix[2][10] = 1
        matrix[3][10] = 1
        matrix[4][10] = 1
        matrix[5][10] = 1
        matrix[6][10] = 1
        matrix[7][10] = 1
        matrix[8][10] = 1
        matrix[9][10] = 1
        matrix[10][10] = 1

        matrix[4][11] = 1

        return matrix

#************************************************* Neighbour Nodes BFS **********************************
def getNeighbourDfs(mazeTable, currentNode):
    x,y = currentNode
    l = []
    if ((x > 0) & (mazeTable[x-1][y]==1)):
       newNode = x-1,y
       l.append( newNode)

    if ((y > 0) & (mazeTable[x][y-1]==1)):
       newNode = x,y-1
       l.append( newNode)
    if y < 11:
      if ((y < len(mazeTable[i])-1 ) & (mazeTable[x][y+1]==1)):
       newNode = x,y+1
       l.append( newNode)
    if x < 11:
     if ( x < 11 &  (mazeTable[x+1][y]==1) ):
       newNode = x+1,j
       l.append( newNode)
    return l  
#************************************************* BFS Implementation**********************************
def BFS(mazeTable,start,dest):
  cost = 0
  visited = set()
  q = Queue()
  q.put(start)
  visited.add(start)
  while q:
       currentNode = q.get()
       print(currentNode)

       if currentNode == dest:
           print("Algorithm used = “BFS”, No of moves utilized = ", cost)
           return

       for neigbour in getNeighbourDfs(mazeTable, currentNode):
        if neigbour not in visited:
               visited.add(neigbour)
               q.put(neigbour)
               cost = cost + 1




if __name__ == "__main__":
    mazeTable = createMazeTable(12,12)
    src = 4,11
    dest = 10,0

    print("\n\t---------------Maze is-----------------")

    for i in range(12):
        for j in range(12):
           print(mazeTable[i][j], end = ' ') 
        print()
    print("\t-----------------------------------------")
    result = BFS(mazeTable,src,dest)